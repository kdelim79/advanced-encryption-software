//---------------------------------------------------------------------------

#ifndef passDecryptH
#define passDecryptH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "cstdlib.h"
#include "iostream.h"
#include "stdio.h"
#include "string.h"
//---------------------------------------------------------------------------
class TfrmPassDecrypt : public TForm
{
__published:	// IDE-managed Components
	TEdit *txtPass;
	TButton *cmdOKPassDecrypt;
	TButton *Button1;
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall cmdOKPassDecryptClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TfrmPassDecrypt(TComponent* Owner);
	int DecFile(char*, char* , char*);
	AnsiString dec_pass;
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmPassDecrypt *frmPassDecrypt;
//---------------------------------------------------------------------------
#endif

//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "main_xor.h"
#include "passDecrypt.h"
#include "rijndael.c"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

#define KEYBITS 256

using namespace std;

TfrmPassDecrypt *frmPassDecrypt;

//---------------------------------------------------------------------------
int DecFile(char* pass, char* infile, char* outfile)
{
	try
	{


		  unsigned long rk[RKLENGTH(KEYBITS)];
		  unsigned char key[KEYLENGTH(KEYBITS)];
		  int i;
		  int nrounds;
		  char *password;
		  FILE *input;
		  FILE *output;

		  password = pass;

		  for (i = 0; i < sizeof(key); i++)
			key[i] = *password != 0 ? *password++ : 0;

		  input = fopen(infile, "rb");
		  output = fopen(outfile,"wb");

		  if (input == NULL)
		  {
			ShowMessage("File read error");
			return 1;
		  }
		  nrounds = rijndaelSetupDecrypt(rk, key, 256);
		  while (1)
		  {
			unsigned char plaintext[16];
			unsigned char ciphertext[16];
			int j;
			if (fread(ciphertext, sizeof(ciphertext), 1, input) != 1)
			  break;
			rijndaelDecrypt(rk, nrounds, ciphertext, plaintext);
			fwrite(plaintext, sizeof(plaintext), 1, output);
		  }
		  fclose(input);
		  fclose(output);

	}
	catch (...)
	{
		ShowMessage("An error occured while decrypting files!!");
		return -1;
	}
    return 1;
}


//---------------------------------------------------------------------------
__fastcall TfrmPassDecrypt::TfrmPassDecrypt(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmPassDecrypt::Button1Click(TObject *Sender)
{
	this->txtPass->PasswordChar = '*';
}
//---------------------------------------------------------------------------
void __fastcall TfrmPassDecrypt::cmdOKPassDecryptClick(TObject *Sender)
{
	try
	{
		frmMain->lbStatus->Caption = "Status: Decryption in process....";
		Application->ProcessMessages();
		this->dec_pass = this->txtPass->Text;
		this->Close();

		frmMain->prog1->Min = 0;
		frmMain->prog1->Max = frmMain->FileListBox1->SelCount;
		frmMain->prog1->Position = 0;
		frmMain->prog1->Step = 1;
		int i;
		int num_of_items = frmMain->FileListBox1->Items->Count;
		AnsiString input_file;
		AnsiString output_file;
		int length;

		for (i=0; i<= num_of_items-1; i++)
		//prospelazoume ena ena ta stoixeia tou listbox....
		{
			//elegxoume an to trexon stoixeio tou listbox einai epilegmeno
			//kai an einai to apokryptografoume.....
			if (frmMain->FileListBox1->Selected[i] == true)
			//sti selected to proto stoixeio exei index 0
			{

				//ftiaxnoume to path tou trexontos epilegmenou arxeiou eisodou
				//arxika pernoume to directory kai meta to epilegmeno file name
				input_file = frmMain->FileListBox1->Directory + "\\";
				input_file = input_file + frmMain->FileListBox1->Items->Strings[i];

				//ftiaxnoume to path tou trexontos arxeiou exodou
				//aferontas tin katalixi .enc apo to telos tou arxeiou....
				output_file = frmMain->txtDestinationFolder->Text;
				if (output_file == "")
				{
					ShowMessage("Please specify destination folder first!!");
					return;
				}

				output_file = output_file + "\\" + frmMain->FileListBox1->Items->Strings[i];
				//edo vlepoume to mikos tou path kai epeita aferoume 4 xaraktires
				//apo to output_file gia na fygei to .enc
				char* S = output_file.c_str();
				length = strlen(S);

				output_file = output_file.SubString(0,length-4);

				//tora apokryptografoume to trexon arxeio.....
				::DecFile(this->dec_pass.c_str(),input_file.c_str(),output_file.c_str());
				frmMain->prog1->StepIt();
			}
			Application->ProcessMessages();
		}
		frmMain->lbStatus->Caption = "Status: Idle";
		ShowMessage("Decryption of files completed successfully.");
		frmMain->prog1->Position = 0;
	}
	catch (...)
	{
		ShowMessage("An error occured while decrypting files!!");
	}

}
//---------------------------------------------------------------------------


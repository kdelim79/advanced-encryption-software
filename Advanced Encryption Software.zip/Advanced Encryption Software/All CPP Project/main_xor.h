//---------------------------------------------------------------------------

#ifndef main_xorH
#define main_xorH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <FileCtrl.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class TfrmMain : public TForm
{
__published:	// IDE-managed Components
	TDriveComboBox *DriveComboBox1;
	TDirectoryListBox *DirectoryListBox1;
	TFileListBox *FileListBox1;
	TButton *cmdAbout;
	TLabel *Label1;
	TButton *cmdDestinationFolder;
	TEdit *txtDestinationFolder;
	TButton *cmdEncrypt;
	TButton *cmdDecrypt;
	TLabel *lbStatus;
	TProgressBar *prog1;
	TButton *cmdSelectAll;
	void __fastcall cmdAboutClick(TObject *Sender);
	void __fastcall cmdDestinationFolderClick(TObject *Sender);
	void __fastcall cmdEncryptClick(TObject *Sender);
	void __fastcall cmdDecryptClick(TObject *Sender);
	void __fastcall cmdSelectAllClick(TObject *Sender);

private:	// User declarations
public:		// User declarations
	__fastcall TfrmMain(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmMain *frmMain;
//---------------------------------------------------------------------------
#endif

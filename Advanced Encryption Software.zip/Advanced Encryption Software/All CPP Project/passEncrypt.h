//---------------------------------------------------------------------------

#ifndef passEncryptH
#define passEncryptH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//#include <vcl.h>
#include "cstdlib.h"
#include "iostream.h"
#include "stdio.h"
#include "string.h"

//---------------------------------------------------------------------------
class TfrmPassEncrypt : public TForm
{
__published:	// IDE-managed Components
	TEdit *txtPass;
	TButton *cmdOKPassEncrypt;
	TButton *Button1;
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall cmdOKPassEncryptClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TfrmPassEncrypt(TComponent* Owner);
	int EncFile(char*, char*, char*);
	AnsiString enc_pass;
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmPassEncrypt *frmPassEncrypt;
//---------------------------------------------------------------------------
#endif

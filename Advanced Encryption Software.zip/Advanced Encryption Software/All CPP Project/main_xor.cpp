//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "passEncrypt.h"
#include "passDecrypt.h"
#include "main_xor.h"
#include "about.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmMain *frmMain;
//---------------------------------------------------------------------------
__fastcall TfrmMain::TfrmMain(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::cmdAboutClick(TObject *Sender)
{
	frmAbout->Show();
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::cmdDestinationFolderClick(TObject *Sender)
{
	AnsiString RootDir = "C:\\";
	if (SelectDirectory("Specify destination folder:", "", RootDir));
	txtDestinationFolder->Text = RootDir;
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::cmdEncryptClick(TObject *Sender)
{
	try
	{
		if (frmMain->FileListBox1->SelCount == 0)
		{
			ShowMessage("Please select at least one file to encrypt from the file list box.");
			return;
		}

		frmPassEncrypt->Show();
	}
	catch (...)
	{
		ShowMessage("An error occured while encrypting. Please check!!");
	}
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::cmdDecryptClick(TObject *Sender)
{
	try
	{
		if (frmMain->FileListBox1->SelCount == 0)
		{
			ShowMessage("Please select at least one file to decrypt from the file list box.");
			return;
		}

		frmPassDecrypt->Show();
	}
	catch (...)
	{
		ShowMessage("An error occured while decrypting. Please check!!");
	}

}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::cmdSelectAllClick(TObject *Sender)
{
	this->FileListBox1->SelectAll();
}
//---------------------------------------------------------------------------


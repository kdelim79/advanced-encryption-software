//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "main_xor.h"
#include "passEncrypt.h"
#include "rijndael.c"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

#define KEYBITS 256

using namespace std;

TfrmPassEncrypt *frmPassEncrypt;

//---------------------------------------------------------------------------
int EncFile(char* pass, char* infile, char* outfile)
{
	try
	{
		unsigned long rk[RKLENGTH(KEYBITS)];
		unsigned char key[KEYLENGTH(KEYBITS)];
		int i;
		int nrounds;
		char *password;
		FILE *output;
		FILE *input;
		password = pass;
		for (i = 0; i < sizeof(key); i++)
		key[i] = *password != 0 ? *password++ : 0;

		input = fopen(infile,"rb");
		output = fopen(outfile, "wb");

		if (output == NULL)
		{
			ShowMessage("File Output Error!");
			return -1;
		}
		nrounds = ::rijndaelSetupEncrypt(rk, key, 256);
		while (!feof(input))
		{
			unsigned char plaintext[16];
			unsigned char ciphertext[16];
			int j;
			for (j = 0; j < sizeof(plaintext); j++)
			{
			  int c = getc(input);
			  if (c == EOF)
			  break;
			  plaintext[j] = c;
			}
			if (j == 0)
			  break;
			for (; j < sizeof(plaintext); j++)
				plaintext[j] = ' ';
			::rijndaelEncrypt(rk, nrounds, plaintext, ciphertext);

			if (fwrite(ciphertext, sizeof(ciphertext), 1, output) != 1)
			{
				fclose(output);
				ShowMessage("File write error!");
				return 1;
			}
		}
		fclose(input);
		fclose(output);

		 return 1;
	}
	catch (...)
	{
		ShowMessage("An error occured while encrypting files!!");
		return -1;
	}
    return 1;

}

//---------------------------------------------------------------------------

__fastcall TfrmPassEncrypt::TfrmPassEncrypt(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmPassEncrypt::Button1Click(TObject *Sender)
{
	this->txtPass->PasswordChar = '*';
}
//---------------------------------------------------------------------------
void __fastcall TfrmPassEncrypt::cmdOKPassEncryptClick(TObject *Sender)
{
	try
	{
		frmMain->lbStatus->Caption = "Status: Encryption in process....";
		Application->ProcessMessages();
		this->enc_pass = this->txtPass->Text;
		this->Close();

		frmMain->prog1->Min = 0;
		frmMain->prog1->Max = frmMain->FileListBox1->SelCount;
		frmMain->prog1->Position = 0;
		frmMain->prog1->Step = 1;
		int i;
		int num_of_items = frmMain->FileListBox1->Items->Count;
		AnsiString input_file;
		AnsiString output_file;

		for (i=0; i<= num_of_items-1; i++)
		//prospelazoume ena ena ta stoixeia tou listbox....
		{
			//elegxoume an to trexon stoixeio tou listbox einai epilegmeno
			//kai an einai to kryptografoume.....
			if (frmMain->FileListBox1->Selected[i] == true)
			//sti selected to proto stoixeio exei index 0
			{
				//ShowMessage(frmMain->FileListBox1->Items->Strings[i]);

				//ftiaxnoume to path tou trexontos epilegmenou arxeiou eisodou
				//arxika pernoume to directory kai meta to epilegmeno file name
				input_file = frmMain->FileListBox1->Directory + "\\";
				input_file = input_file + frmMain->FileListBox1->Items->Strings[i];

				//ftiaxnoume to path tou trexontos arxeiou exodou me tin katalixi
				//.enc prostithemeni sto telos tou arxeiou....
				output_file = frmMain->txtDestinationFolder->Text;
				if (output_file == "")
				{
					ShowMessage("Please specify destination folder first!!");
					return;
				}
				output_file = output_file + "\\" + frmMain->FileListBox1->Items->Strings[i] + ".enc";
				//tora kryptografoume to trexon arxeio.....
				::EncFile(this->enc_pass.c_str(),input_file.c_str(),output_file.c_str());
				frmMain->prog1->StepIt();
			}
			Application->ProcessMessages();			
		}
		frmMain->lbStatus->Caption = "Status: Idle";
		ShowMessage("Encryption of files completed successfully.");
		frmMain->prog1->Position = 0;
	}
	catch (...)
	{
		ShowMessage("An error occured while encrypting files!!");
	}
}
//---------------------------------------------------------------------------



